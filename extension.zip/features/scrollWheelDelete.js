let enabled = false;

function enableScrollWheelDelete() {

  // Keep track of mouse pos
  document.addEventListener('mousemove', e => {
    const mousePos = [e.clientX, e.clientY];
    if (enabled) {
      document.dispatchEvent(new MouseEvent('mouseup', {'button': 1, "clientX": mousePos[0], "clientY": mousePos[1], 'bubbles': true}));
    }
  });

  // Handle both types of key presses
  function keyHandler(e, en) {
    if (e.button === 1) {
      enabled = en;
    }
  }
  
  // Register events
  document.addEventListener('mousedown', e => keyHandler(e, true));
  document.addEventListener('mouseup', e => keyHandler(e, false));
}

